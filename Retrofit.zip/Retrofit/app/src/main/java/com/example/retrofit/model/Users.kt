package com.example.retrofit.model

import com.google.gson.annotations.SerializedName


data class Users (
    val image: String? = null,
    val id: Int? = null,
    val title: String? = null
)